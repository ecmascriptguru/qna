<?php
namespace App\Api;

use App\Classes\QnaType as Type;

$conn = null;
$type = new Type($conn);

class Something {
    //
}
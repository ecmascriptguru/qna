<?php
header("Location: /api/docs.html");
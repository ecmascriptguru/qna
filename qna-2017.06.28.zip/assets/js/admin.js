(function(window, jQuery) {
    QuestionGenerator.init("tool-container", QNAConfig.baseUrl());
})(window, $);
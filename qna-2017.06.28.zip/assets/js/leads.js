(function(window, jQuery) {
    QuestionRenderer.init("qna-container", QNAConfig.baseUrl());
})(window, $);
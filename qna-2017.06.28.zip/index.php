<?php
require_once("config/env.php");
header("Location: {$BASE_URL}/admin.php");